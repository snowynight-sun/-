package controller;
import javax.swing.JFrame;
import view.Tetris;;
public class startTetris {
	public static void main(String[] args) {
		Tetris.loginTetris();
}
}
